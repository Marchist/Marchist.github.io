import pandas as pd
import flet as ft
from flet import (
    Checkbox,
    Column,
    FloatingActionButton,
    IconButton,
    Page,
    Row,
    Tab,
    Tabs,
    TextField,
    UserControl,
    colors,
    icons,
    ElevatedButton,
    Text,
    DataColumn
)

df = pd.read_excel('EZ2ON ALL SONGS.xlsx')
df_filtered = pd.DataFrame()




class Convert(UserControl):
    def build(self):
        self.scoring_data = TextField(
                hint_text="scoring_data.txt를 복사하여 그대로 붙여넣기 하세요",
                multiline=True,
                min_lines=10,
                max_lines=10,
                value="",
            )
        self.convert_button = ElevatedButton("변환", on_click=self.convert_click)
        self.please_wait = Text("")
        return Column(controls=[self.scoring_data, self.convert_button, self.please_wait])

    def convert_click(self, e):
        self.please_wait.value = "잠시만 기다려주세요..."
        self.update()

        lines = self.scoring_data.value.split('\n')
        lines.pop()
        lines = list(map(int, lines))
        df_score = pd.DataFrame({'SCORE':lines})
        df.insert(loc=7, column='SCORE', value=df_score)
        self.visible = False
        self.update()



class AfterConvert(UserControl):
    def build(self):
        self.displayed_list = ft.ListView(expand=1, spacing=10, padding=20)

    def df_display(self, e):
        df_filtered = df.loc[df['LEVEL'] == 20].reset_index(drop=True)
        columnsss=[
            ft.DataColumn(ft.Text("CATE")),
            ft.DataColumn(ft.Text("TITLE")),
            ft.DataColumn(ft.Text("MODE")),
            ft.DataColumn(ft.Text("DIFF")),
            ft.DataColumn(ft.Text("LEVEL"), numeric=True),
            ft.DataColumn(ft.Text("NOTES"), numeric=True),
            ft.DataColumn(ft.Text("INDEX"), numeric=True),
            ft.DataColumn(ft.Text("SCORE"), numeric=True),
        ]
        columnsss = []
        for col in df.columns:
            if col in ("LEVEL", "NOTES", "INDEX", "SCORE"):
                columnsss.append(DataColumn(Text(col)), numeric=True)
            else:
                columnsss.append(DataColumn(Text(col)))

        rowsss = []

        if len(df_filtered) > 500:
            print('TOO MANY!!!')
        else:
            print(df_filtered)
            for i in range(0, len(df_filtered)):
                row = list(df_filtered.loc[i])
                cellsss = []
                for j in range(0, 8):
                    cellsss.append(ft.DataCell(ft.Text(row[j])))
                rowsss.append(ft.DataRow(cells=cellsss))
            self.displayed_list.controls.append(ft.DataTable(columns=columnsss, rows=rowsss))
        self.update()



class Main(UserControl):
    def build(self):
        convert_hwamyeon = Convert()
        return convert_hwamyeon
    

    


def main(page: Page):

    page.title = "EASY READER"
    page.horizontal_alignment = "center"
    page.update()

    app = Main()
    page.add(app)

ft.app(target=main, view=ft.AppView.WEB_BROWSER)