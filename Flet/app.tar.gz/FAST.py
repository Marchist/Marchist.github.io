from flet import Page, Dropdown, dropdown, app, AppView, TextField, ElevatedButton, Container

def main(page: Page):

    def clicked(e):
        sort_dropdown.text_size = asdf.value
        sort_dropdown.update()

    def clicked2(e):
        sort_dropdown_container.height = asdf2.value
        sort_dropdown_container.update()

    sort_dropdown = Dropdown(width=150,
            options=[
                dropdown.Option("점수"),
                dropdown.Option("레벨 내림차순"),
                dropdown.Option("레벨 오름차순"),
                dropdown.Option("제목"),
            ],
            hint_text="정렬 1",
            text_size=24
        )
    
    sort_dropdown_container = Container(content = sort_dropdown, height=150)

    asdf = TextField()
    button = ElevatedButton("변환", on_click=clicked, data=0)
    asdf2 = TextField()
    button2 = ElevatedButton("변환", on_click=clicked2, data=0)
    page.add(asdf, button, asdf2, button2, sort_dropdown_container)

app(target=main)