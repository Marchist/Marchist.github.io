from math import floor
TIER_BORDER = [9850, 9750, 9650, 9200, 8400, 7000, 5500, 4100, 2500, 0]
TIER = ["CONQUEROR", "CHALLENGER", "GRANDMASTER", "MASTER", "DIAMOND", "PLATINUM", "GOLD", "SILVER", "BRONZE", "IRON"]

def get_tier(tp):
    ROME = [' IV', ' III', ' II', ' I']
    for i in range(0, len(TIER_BORDER)):
        if tp >= TIER_BORDER[i]:
            tier = TIER[i]
            break
    if tier in ['GRANDMASTER', 'CHALLENGER', 'CONQUEROR']:
        return tier
    else:
        if tp < 1000: return 'IRON IV'
        elif tp < 1500: return 'IRON III'
        elif tp < 2000: return 'IRON II'
        elif tp < 2500: return 'IRON I'
        else:
            if tier == 'MASTER': gupgan = 100
            elif tier == 'DIAMOND': gupgan = 200
            elif tier in ['SILVER', 'GOLD', 'PLATINUM']: gupgan = 300
            else: gupgan = 400

            rome = min(floor((tp - TIER_BORDER[i]) / gupgan), 3)
            return tier + ROME[rome]

for tp in range(10000, -1, -100):
    print(tp, get_tier(tp))