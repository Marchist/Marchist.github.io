import flet
import pandas as pd
from math import floor
from collections import Counter
from flet import (
    AppBar,
    Checkbox,
    Column,
    FloatingActionButton,
    IconButton,
    Page,
    Row,
    Tab,
    Tabs,
    TextField,
    UserControl,
    colors,
    icons,
    ElevatedButton,
    Text,
    View,
    DataColumn,
    DataCell,
    DataRow,
    DataTable,
    ListView,
    Dropdown,
    Icon,
    border,
    colors,
    FontWeight,
    padding,
    dropdown,
    PopupMenuButton,
    PopupMenuItem,
    Container,
    alignment,
    Image,
    TextAlign
)

df = pd.read_excel('EZ2ON ALL SONGS.xlsx')
df_filtered = pd.DataFrame()
cnt_4 = Counter(df.loc[df['MODE'] == '4S']['LEVEL'])
cnt_5 = Counter(df.loc[df['MODE'] == '5S']['LEVEL'])
cnt_6 = Counter(df.loc[df['MODE'] == '6S']['LEVEL'])
cnt_8 = Counter(df.loc[df['MODE'] == '8S']['LEVEL'])
tierpoint_max_list = []
for i, cnt in enumerate([cnt_4, cnt_5, cnt_6, cnt_8]):
    lv20, lv19, lv18 = (cnt[20]-1, cnt[19]-1, cnt[18])
    if i >= 1:
        lv20 -= 1
    if lv20 + lv19 >= 50:
        lv19 = 50 - lv20
        lv18 = 0
    else:
        lv18 = 50 - (lv19 + lv20)
    tierpoint_max_list.append(300 * lv20 + 260 * lv19 + 225 * lv18)
print(tierpoint_max_list)

# region INITIALIZE
TIER_BAN = ['Altered Ego', 'starflyer', '8th Planet (Progressive House Remix)', 'Last Flight', 'Sudden Death']
RATING_BAN = ['Altered Ego', 'starflyer', '8th Planet (Progressive House Remix)', 'Last Flight', 'Sudden Death', 'Love & Extasy', 'Mystic Dream 9903(Horror Mix)', 'Black Key']

TIER_BORDER = [9850, 9750, 9650, 9200, 8400, 7000, 5500, 4100, 2500, 0]
TIER = ["CONQUEROR", "CHALLENGER", "GRANDMASTER", "MASTER", "DIAMOND", "PLATINUM", "GOLD", "SILVER", "BRONZE", "IRON"]
CATEGORIES = ['1ST', '2ND', '3RD', '4TH', 'PT', '6TH', '7TH', '2008', '2013', '2021', 'TT', 'CV', 'PP', 'O2', 'GC', 'EC', 'FT', 'DM'] 
COLUMNS = ['CATEGORY', 'TITLE', 'MODE', 'SCORE', 'RATE', 'DIFFICULTY', 'LEVEL', 'NOTES', 'TIER']
MODES = ['4S', '5S', '6S', '8S']
RANKS = ['S+++', 'S++', 'S+', 'S', 'A+', 'A', 'B', 'CDEF', 'NO PLAY']
LEVELS = [i for i in range(20, 0, -1)]

NUM_CATEGORIES = len(CATEGORIES)
NUM_COLUMNS = len(COLUMNS)
NUM_RANKS = len(RANKS)

column_filter = [True, True, True, True, False, True, True, False, True]
level_filter = [False] * 20
mode_filter = [False] * 4
rank_filter = [False] * NUM_RANKS
category_filter = [False] * NUM_CATEGORIES

column_filter_default = column_filter.copy()
level_filter_default = level_filter.copy()
mode_filter_default = mode_filter.copy()
rank_filter_default = rank_filter.copy()
category_filter_default = category_filter.copy()

before_tierpoints = []
after_tierpoints = []
tier_objects = []
tier_list_objects = []
# endregion

class MyCheckbox(UserControl):
    def __init__(self, whattype, index):
        super().__init__()
        disabled_to_be = True
        if whattype == 'Level':
            self.filter = level_filter
            self.filter_default = level_filter_default
            self.label = LEVELS
        elif whattype == 'Column':
            self.filter = column_filter
            self.filter_default = column_filter_default
            self.label = COLUMNS
            disabled_to_be = False
        elif whattype == 'Mode':
            self.filter = mode_filter
            self.filter_default = mode_filter_default
            self.label = MODES
        elif whattype == 'Rank':
            self.filter = rank_filter
            self.filter_default = rank_filter_default
            self.label = RANKS
        elif whattype == 'Category':
            self.filter = category_filter
            self.filter_default = category_filter_default
            self.label = CATEGORIES
        self.index = index
        self.checkbox = Checkbox(
            value=self.filter_default[self.index], label=self.label[self.index], on_change=self.checkbox_changed, disabled=disabled_to_be
            )

    def checkbox_changed(self, e):
        self.filter[(self.index)] = self.checkbox.value
        pass

    def build(self):
        return self.checkbox

def main(page: Page):

    def convert_click(e):
        def get_rank(s):
            ret = 'NO PLAY'
            if s >= 1090000: ret = 'S+++'
            elif s >= 1050000: ret = 'S++'
            elif s >= 1025000: ret = 'S+'
            elif s >= 1000000: ret = 'S'
            elif s >= 950000: ret = 'A+'
            elif s >= 900000: ret = 'A'
            elif s >= 850000: ret = 'B'
            elif s > 0: ret = 'CDEF'
            return ret

        def get_tierpoint(lv, n, s, t):
            if lv == 20: lvpoint = 300
            elif lv == 19: lvpoint = 260
            elif lv == 18: lvpoint = 225
            elif lv == 17: lvpoint = 200
            elif lv == 16: lvpoint = 180
            elif lv == 15: lvpoint = 160
            else: lvpoint = lv*10
            rate = s / (1100000+n)
            tierpoint = lvpoint * min(1, max(rate*100-55, 0) ** 1.209765825 / 100)
            return (round(tierpoint,3) if t not in TIER_BAN else 0), floor(rate*100000)/1000

        if convert_button.data == 0:
            convert_button.data = 1
            please_wait.value = "변환중..."
            page.update()

            # region 삽입
            lines = scoring_data.value.split('\n')
            lines.pop()
            if len(lines) != len(df):
                convert_button.data = 0
                please_wait.value = f"행수 불일치 (ALL SONGS = {len(df)} / scoring_data = {len(lines)} / {(len(df) - len(lines))//16}곡 부족)"
                page.update()
                return
            
            lines = list(map(int, lines))
            ranks = []
            for line in lines:
                ranks.append(get_rank(line))
            df.insert(loc=7, column='SCORE', value=pd.DataFrame({'SCORE':lines}))
            df.insert(loc=8, column='RANK', value=pd.DataFrame({'RANK':ranks}))
            # endregion

            # region 티어포인트 산출
            tierpoints = []
            rates = []
            for idx, row in df.iterrows():
                tp, rate = get_tierpoint(lv = row['LEVEL'], n = row['NOTES'], s = row['SCORE'], t = row['TITLE'])
                tierpoints.append(tp)
                rates.append(rate)

            df.insert(loc=9, column='TIER', value=pd.DataFrame({'TIER':tierpoints}))
            df.insert(loc=10, column='RATE', value=pd.DataFrame({'RATE':rates}))

            for i, mode in enumerate(['4S', '5S', '6S', '8S']):
                before_tp = round(df.loc[df['MODE'] == mode].sort_values(by='TIER', ascending=False).head(50).sum()['TIER'], 3)
                before_tierpoints.append(before_tp)
                after_tierpoints.append(round(before_tp / tierpoint_max_list[i] * 10000, 3))
            # endregion
            
            # region 좌측 컨테이너
            for i in range(0, 4):
                tier, tier_i = get_tier(after_tierpoints[i])
                mode = [4, 5, 6, 8][i]
                image_container = Container(content = 
                    Image(src = f'tier ({tier_i}).png', width=100, height=100), padding=padding.only(left=10), alignment=alignment.center
                )
                text_column=Column(controls=[
                    Text(value = f"{mode}K STANDARD", font_family="Mon2", size=18, width=220, text_align=TextAlign.CENTER),
                    Text(value = tier, font_family="Mon3", size=26, width=220, text_align=TextAlign.CENTER),
                    Text(value = after_tierpoints[i], font_family="Mon2", size=14, width=220, text_align=TextAlign.CENTER)],
                    spacing = 4)
                    
                text_container = Container(content = text_column, height=100, alignment=alignment.center, padding=padding.only(top=3.5))
                    
                tier_object = Row(controls=[image_container,text_container])
                tier_objects.append(Container(content=tier_object,
                width=350,
                height=150,
                border_radius=10,
                border=border.all(2, colors.BLACK),
                padding=padding.only(right=10)
                ))
            # endregion

            # region 우측 컨테이너
            tier_displayed_list = ListView(expand=1, spacing=5, padding=padding.only(right=800))
            tier_displayed_list.controls.append(Text("Hi"))
            
            df_filtered = df.loc[df['MODE'] == '4S']
            df_filtered = df_filtered.sort_values('TIER', ascending=False).reset_index(drop=True).head(50)
            df_filtered = df_filtered[['CATEGORY', 'TITLE', 'TIER', 'DIFFICULTY', 'LEVEL', 'SCORE', 'RATE']]

            columnsss = []
            for col in df_filtered.columns:
                columnsss.append(DataColumn(Text(col)))

            rowsss = []
            for i in range(0, len(df_filtered)):
                row = dict(df_filtered.loc[i])
                cellsss = []
                for col, item in df_filtered.items():
                    if col == "TIER":
                        cellsss.append(DataCell(Text(format(row[col], '.3f'))))
                    elif col == "RATE":
                        cellsss.append(DataCell(Text(f'{format(row[col], ".3f")}%')))
                    elif col == "SCORE":
                        cellsss.append(DataCell(Text(format(row[col], ','))))
                    else:
                        cellsss.append(DataCell(Text(row[col])))
                rowsss.append(DataRow(cells=cellsss))

            tier_displayed_list.controls.append(DataTable(
                border=border.all(1, "black"),
                border_radius=10,
                column_spacing=50,
                columns=columnsss, 
                rows=rowsss,
                data_row_max_height = 45,
                ))

            tier_list_objects.append(tier_displayed_list)
            # endregion

            page.views.clear()
            page.views.append(view_after)
            page.update()
            sort_dropdown_1.value = "점수"
            sort_dropdown_1.update()

    def get_column_filter():
        asdf = []
        for i in range(0, 9):
            if column_filter[i]:
                asdf.append(COLUMNS[i])
        return asdf
    
    def get_filter(whattype, ifALL):
        if whattype == 'Level':
            filter = level_filter
            num = 20
            label = "LEVEL"
            const = LEVELS
        elif whattype == 'Mode':
            filter = mode_filter
            num = 4
            label = "MODE"
            const = MODES
        elif whattype == 'Rank':
            filter = rank_filter
            num = 9
            label = "RANK"
            const = RANKS
        elif whattype == 'Category':
            filter = category_filter
            num = 18
            label = "CATEGORY"
            const = CATEGORIES
        ret = []
        for i in range(0, num):
            if filter[i]:
                ret.append(const[i])
        if ifALL:
            print(whattype, 'ALL')
            return df[label].isin(const)
        else:
            print(whattype, ret)
            return df[label].isin(ret)

    def ALL_clicked(e):
        if e.control.data == 'Level':
            num = 20
            checkbox_list = level_checkbox_list
        elif e.control.data == 'Mode':
            num = 4
            checkbox_list = mode_checkbox_list
        elif e.control.data == 'Category':
            num = 18
            checkbox_list = category_checkbox_list
        elif e.control.data == 'Rank':
            num = 9
            checkbox_list = rank_checkbox_list
        for i in range(0, num):
            checkbox_list[i].checkbox.disabled=e.control.value
            checkbox_list[i].update()
        view_after.update()

    def get_sort(whattype):
        if whattype == '제목':
            return 'TITLE', True
        elif whattype == '점수':
            return 'SCORE', False
        elif whattype == '레벨 오름차순':
            return 'LEVEL', True
        elif whattype == '레벨 내림차순':
            return 'LEVEL', False
        elif whattype == '티어 포인트':
            return 'TIER', False
        elif whattype == '노트 수':
            return 'NOTES', False
        elif whattype == 'JUDGE RATE':
            return 'RATE', False
        else:
            return False, None

    def df_display(e):
        displayed_list.clean()
        displayed_list_text = Text("처리중...")
        displayed_list.controls.append(displayed_list_text)
        displayed_list.update()
        
        df_column_filter = get_column_filter()
        df_level_filter = get_filter('Level', ifALL = ALL_level_checkbox.value)
        df_mode_filter = get_filter('Mode', ifALL = ALL_mode_checkbox.value)
        df_rank_filter = get_filter('Rank', ifALL = ALL_rank_checkbox.value)
        df_category_filter = get_filter('Category', ifALL = ALL_category_checkbox.value)

        df_filtered = df.loc[df_level_filter].loc[df_mode_filter].loc[df_rank_filter].loc[df_category_filter]

        sorts = []
        ascendings = []
        sort_1, sort_1_asc = get_sort(sort_dropdown_1.value)
        sort_2, sort_2_asc = get_sort(sort_dropdown_2.value)
        sort_3, sort_3_asc = get_sort(sort_dropdown_3.value)

        if sort_1:
            sorts.append(sort_1)
            ascendings.append(sort_1_asc)
        if sort_2:
            sorts.append(sort_2)
            ascendings.append(sort_2_asc)
        if sort_3:
            sorts.append(sort_3)
            ascendings.append(sort_3_asc)

        df_filtered = df_filtered.sort_values(sorts, ascending=ascendings).reset_index(drop=True)

        score_avg = int(df_filtered["SCORE"].mean()) if len(df_filtered) > 0 else 0
        non_zero_len = len(df_filtered)-len(df_filtered.loc[df_filtered['SCORE'] == 0])
        non_zero_avg = int(df_filtered['SCORE'].sum() / non_zero_len) if non_zero_len > 0 else 0
        displayed_list_stats = Text(
                f'개수 = {len(df_filtered)} | 클리어 = {len(df_filtered.loc[df_filtered["SCORE"] > 0])} | 클리어 평균 = {format(non_zero_avg, ",")} | 전체 평균 = {format(score_avg, ",")}'
                )
        
        df_filtered = df_filtered[df_column_filter]

        columnsss = []
        for col in df_filtered.columns:
            if col in ("LEVEL", "NOTES", "INDEX", "SCORE", "TIER", "RATE"):
                columnsss.append(DataColumn(Text(col), numeric=True))
            else:
                columnsss.append(DataColumn(Text(col)))

        rowsss = []
        if len(df_filtered) > 1000:
            displayed_list_text.value = f"1000건 초과!!! ({len(df_filtered)}건)"
        elif len(df_filtered) <= 0:
            displayed_list_text.value = "결과 없음"
        else:
            for i in range(0, len(df_filtered)):
                row = dict(df_filtered.loc[i])
                cellsss = []
                for col, item in df_filtered.items():
                    if col == "TIER":
                        cellsss.append(DataCell(Text(format(row[col], '.3f'))))
                    elif col == "RATE":
                        cellsss.append(DataCell(Text(f'{format(row[col], ".3f")}%')))
                    elif col == "SCORE":
                        cellsss.append(DataCell(Text(format(row[col], ','))))
                    else:
                        cellsss.append(DataCell(Text(row[col])))
                rowsss.append(DataRow(cells=cellsss))

            displayed_list.controls.pop()
            displayed_list.controls.append(displayed_list_stats)
            displayed_list.controls.append(DataTable(
                border=border.all(1, "black"),
                border_radius=10,
                column_spacing=50,
                columns=columnsss, 
                rows=rowsss,
                data_row_max_height = 45,
                ))
        page.update()

    #region view_before
    scoring_data = TextField(
                hint_text="scoring_data.txt를 복사하여 그대로 붙여넣기 하세요",
                multiline=True,
                min_lines=10,
                max_lines=10,
                value="",
            )
    convert_button = ElevatedButton("변환", on_click=convert_click, data=0)
    please_wait = Text("")
    EASY_text = Text("EASY URL", weight=FontWeight.BOLD)
    EASY_url = TextField(value = "https://gall.dcinside.com/mgallery/board/view/?id=ez2on&no=198055")
    EASY_text2 = Text("ONE = 258 / NUM_SONGS = 429 (23.12.12 기준)", color=colors.RED)
    view_before = View(controls=[scoring_data, convert_button, please_wait, EASY_text, EASY_url, EASY_text2])
    #endregion 

    #region view_after_tab1
    level_checkbox_list = []
    column_checkbox_list = []
    mode_checkbox_list = []
    rank_checkbox_list = []
    category_checkbox_list = []
    for i in range(0, 20):
        new_checkbox = MyCheckbox(index=i, whattype='Level')
        level_checkbox_list.append(new_checkbox)
    for i in range(0, 4):
        new_checkbox = MyCheckbox(index=i, whattype='Mode')
        mode_checkbox_list.append(new_checkbox)
    for i in range(0, NUM_COLUMNS):
        new_checkbox = MyCheckbox(index=i, whattype='Column')
        column_checkbox_list.append(new_checkbox)
    for i in range(0, NUM_RANKS):
        new_checkbox = MyCheckbox(index=i, whattype='Rank')
        rank_checkbox_list.append(new_checkbox)
    for i in range(0, NUM_CATEGORIES):
        new_checkbox = MyCheckbox(index=i, whattype='Category')
        category_checkbox_list.append(new_checkbox)

    column_checkboxes = Row(controls=column_checkbox_list)
    category_checkboxes = Row(controls=category_checkbox_list)
    level_checkboxes = Row(controls=level_checkbox_list)
    mode_checkboxes = Row(controls=mode_checkbox_list)
    rank_checkboxes = Row(controls=rank_checkbox_list)

    ALL_category_checkbox = Checkbox(value=True, label="ALL", on_change=ALL_clicked, data='Category')
    ALL_level_checkbox = Checkbox(value=True, label="ALL", on_change=ALL_clicked, data='Level')
    ALL_mode_checkbox = Checkbox(value=True, label="ALL", on_change=ALL_clicked, data='Mode')
    ALL_rank_checkbox = Checkbox(value=True, label="ALL", on_change=ALL_clicked, data='Rank')

    display_button = ElevatedButton("표시", on_click=df_display, data=0)
    displayed_list = ListView(expand=1, spacing=5, padding=padding.only(right=800))

    base_options = [
            dropdown.Option("점수"),
            dropdown.Option("레벨 내림차순"),
            dropdown.Option("레벨 오름차순"),
            dropdown.Option("제목"),
            dropdown.Option("티어 포인트"),
            dropdown.Option("노트 수"),
            dropdown.Option("JUDGE RATE"),
    ]
    sort_dropdown_1 = Dropdown(width=150,
        options=(base_options),
        hint_text="정렬 1",
        text_size=14
    )
    sort_dropdown_2 = Dropdown(width=150,
        options=([dropdown.Option("---")] + base_options),
        hint_text="정렬 2",
        text_size=14
    )
    sort_dropdown_3 = Dropdown(width=150,
        options=([dropdown.Option("---")] + base_options),
        hint_text="정렬 3",
        text_size=14
    )

    sort_dropdown_1_container = Container(sort_dropdown_1, height=50)
    sort_dropdown_2_container = Container(sort_dropdown_2, height=50)
    sort_dropdown_3_container = Container(sort_dropdown_3, height=50)
    
    tab1_content = Column(controls=[
        Row(controls=[Text("카테고리"), ALL_category_checkbox, category_checkboxes]), 
        Row(controls=[Text("레벨"), ALL_level_checkbox, level_checkboxes]), 
        Row(controls=[Text("모드"), ALL_mode_checkbox, mode_checkboxes, Container(padding=padding.only(right=100)), Text("랭크"), ALL_rank_checkbox, rank_checkboxes]), 
        Row(controls=[Text("열"), column_checkboxes]),
        Row(controls=[sort_dropdown_1_container, sort_dropdown_2_container, sort_dropdown_3_container]),
        display_button,
        displayed_list])
    # endregion

    #region view_after_tab2
    def get_tier(tp):
        ROME = [' IV', ' III', ' II', ' I']
        for i in range(0, 10):
            if tp >= TIER_BORDER[i]:
                tier = TIER[i]
                break
        if tier in ['GRANDMASTER', 'CHALLENGER', 'CONQUEROR']:
            return (tier, 10 - i)
        else:
            if tp < 1000: return 'IRON IV'
            elif tp < 1500: return 'IRON III'
            elif tp < 2000: return 'IRON II'
            elif tp < 2500: return 'IRON I'
            else:
                if tier == 'MASTER': gupgan = 100
                elif tier == 'DIAMOND': gupgan = 200
                elif tier in ['SILVER', 'GOLD', 'PLATINUM']: gupgan = 300
                else: gupgan = 400

                rome = min(floor((tp - TIER_BORDER[i]) / gupgan), 3)
                return (tier + ROME[rome], 10 - i)
            
    tier_objects_column = Column(controls = tier_objects)
    tier_list_objects_column = Column(controls = tier_list_objects)
    tab2_content = Row(controls = [tier_objects_column, tier_list_objects_column])
    # endregion
    t = Tabs(
        selected_index=0,
        animation_duration=200,
        tabs=[
            Tab(text="필터", content=Container(content = tab1_content, padding=padding.only(top=10))),
            Tab(text="티어", content=Container(content = tab2_content, padding=padding.only(top=10)))
        ],
        expand=1
    )

    view_after = View(controls=[t])
    page.fonts = {
            "Mon1" : "Montserrat-Light.ttf",
            "Mon2" : "Montserrat-Medium.ttf",
            "Mon3" : "Montserrat-Bold.ttf"
            }
    page.title = "EASY READER"
    page.views.append(view_before)
    page.update()
    
flet.app(target=main, view=flet.AppView.WEB_BROWSER, assets_dir="Assets")