import pandas as pd

'''
행, 열 수                       df.shape
모든 열                         df.columns
거주인구 열의 값                df['거주인구']
2행 5열 값                      df.iloc[2,5]
0행 값                          df.loc[0]
csv 읽기                        df = pd.read_csv('https://raw.githubusercontent.com/Datamanim/pandas/main/Jeju.csv',encoding='euc-kr')
new_price값이 9 이하이고 item_name 값이 Chicken Salad Bowl 인 데이터 프레임을 추출하라
df.loc[(df.item_name =='Chicken Salad Bowl') & (df.new_price <= 9)]
item_name 컬럼 값중 Chips 포함하는 경우의 데이터를 출력하라
df.loc[df.item_name.str.contains('Chips')]
데이터 프레임 재정의            df[['quantity','item_price']]
전체 행 개수                    len(df)
'''

df = pd.read_excel('EZ2ON ALL SONGS.xlsx')
df2 = pd.read_table('scoring_data.txt',header=None,names=['SCORE'])
df.insert(loc=7, column='SCORE', value=df2['SCORE'])
#print(df.loc[df['LEVEL'] == 20])
print(len(df.loc[df['LEVEL'] == 20].loc[df['SCORE'] == 0]))
print(df.sort_values('SCORE', ascending=False).head(50).sum()['SCORE'])